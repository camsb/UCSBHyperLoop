SDMMC benchmark example

Example description
This example measures the performance of SD/MMC raw read & write 
operations.

To use the example, plug a SD card,  connect a serial cable to the board's
RS232/UART port and start a terminal program to monitor the port.  The
terminal program on the host PC should be setup for 115K8N1.

Special connection requirements
There are no special connection requirements for this example.
